1. Go to main-app directory
	$cd main-app
2. Copy and replace the /build directory in the existing main-app deployment.
3. Restart nginx
	$ sudo service nginx restart