1.Copy and paste the /main-api/dist to existing or the path of the instance running in pm2.
  $cp -r deployment-10142022/main-api/dist /home/administrator/src/Aphrodite/main-api
2.Reload updated patch of main-api  
  $pm2 reload main-api