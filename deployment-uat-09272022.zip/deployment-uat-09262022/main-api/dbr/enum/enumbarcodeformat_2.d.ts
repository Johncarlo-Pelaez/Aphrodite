export declare enum EnumBarcodeFormat_2 {
    BF2_NULL = 0,
    BF2_POSTALCODE = 32505856,
    BF2_NONSTANDARD_BARCODE = 1,
    BF2_USPSINTELLIGENTMAIL = 1048576,
    BF2_POSTNET = 2097152,
    BF2_PLANET = 4194304,
    BF2_AUSTRALIANPOST = 8388608,
    BF2_RM4SCC = 16777216,
    BF2_DOTCODE = 2
}
//# sourceMappingURL=enumbarcodeformat_2.d.ts.map