export declare enum EnumColourConversionMode {
    CICM_GENERAL = 1,
    CICM_SKIP = 0,
    CICM_REV = 2147483648
}
//# sourceMappingURL=enumcolourconversionmode.d.ts.map