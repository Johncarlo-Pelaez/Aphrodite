export declare enum EnumRegionPredetectionMode {
    RPM_AUTO = 1,
    RPM_GENERAL = 2,
    RPM_GENERAL_RGB_CONTRAST = 4,
    RPM_GENERAL_GRAY_CONTRAST = 8,
    RPM_GENERAL_HSV_CONTRAST = 16,
    RPM_SKIP = 0,
    RPM_REV = 2147483648
}
//# sourceMappingURL=enumregionpredetectionmode.d.ts.map