export declare enum EnumIntermediateResultSavingMode {
    IRSM_MEMORY = 1,
    IRSM_FILESYSTEM = 2,
    IRSM_BOTH = 4
}
//# sourceMappingURL=enumintermediateresultsavingmode.d.ts.map