export declare enum EnumQRCodeErrorCorrectionLevel {
    QRECL_ERROR_CORRECTION_H = 0,
    QRECL_ERROR_CORRECTION_L = 1,
    QRECL_ERROR_CORRECTION_M = 2,
    QRECL_ERROR_CORRECTION_Q = 3
}
//# sourceMappingURL=enumqrcodeerrorcorrectionlevel.d.ts.map