export declare enum EnumBinarizationMode {
    BM_AUTO = 1,
    BM_LOCAL_BLOCK = 2,
    BM_SKIP = 0,
    BM_THRESHOLD = 4,
    BM_REV = 2147483648
}
//# sourceMappingURL=enumbinarizationmode.d.ts.map