export declare enum EnumDPMCodeReadingMode {
    DPMCRM_AUTO = 1,
    DPMCRM_GENERAL = 2,
    DPMCRM_SKIP = 0,
    DPMCRM_REV = 2147483648
}
//# sourceMappingURL=enumdpmcodereadingmode.d.ts.map