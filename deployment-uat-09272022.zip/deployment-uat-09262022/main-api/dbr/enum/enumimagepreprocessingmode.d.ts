export declare enum EnumImagePreprocessingMode {
    IPM_AUTO = 1,
    IPM_GENERAL = 2,
    IPM_GRAY_EQUALIZE = 4,
    IPM_GRAY_SMOOTH = 8,
    IPM_SHARPEN_SMOOTH = 16,
    IPM_MORPHOLOGY = 32,
    IPM_SKIP = 0,
    IPM_REV = 2147483648
}
//# sourceMappingURL=enumimagepreprocessingmode.d.ts.map