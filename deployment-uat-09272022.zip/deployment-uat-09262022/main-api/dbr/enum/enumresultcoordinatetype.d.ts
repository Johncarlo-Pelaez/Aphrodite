export declare enum EnumResultCoordinateType {
    RCT_PIXEL = 1,
    RCT_PERCENTAGE = 2
}
//# sourceMappingURL=enumresultcoordinatetype.d.ts.map