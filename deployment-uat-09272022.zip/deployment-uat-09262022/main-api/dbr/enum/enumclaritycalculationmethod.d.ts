export declare enum EnumClarityCalculationMethod {
    ECCM_CONTRAST = 1
}
//# sourceMappingURL=enumclaritycalculationmethod.d.ts.map