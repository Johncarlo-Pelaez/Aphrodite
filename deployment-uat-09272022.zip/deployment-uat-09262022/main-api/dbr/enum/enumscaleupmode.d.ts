export declare enum EnumScaleUpMode {
    SUM_AUTO = 1,
    SUM_LINEAR_INTERPOLATION = 2,
    SUM_NEAREST_NEIGHBOUR_INTERPOLATION = 4,
    SUM_SKIP = 0,
    SUM_REV = 2147483648
}
//# sourceMappingURL=enumscaleupmode.d.ts.map