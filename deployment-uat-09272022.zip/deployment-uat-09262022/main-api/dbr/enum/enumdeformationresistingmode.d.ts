export declare enum EnumDeformationResistingMode {
    DRM_AUTO = 1,
    DRM_GENERAL = 2,
    DRM_SKIP = 0,
    DRM_REV = 2147483648
}
//# sourceMappingURL=enumdeformationresistingmode.d.ts.map