export declare enum EnumIMResultDataType {
    IMRDT_IMAGE = 1,
    IMRDT_CONTOUR = 2,
    IMRDT_LINESEGMENT = 4,
    IMRDT_LOCALIZATIONRESULT = 8,
    IMRDT_REGIONOFINTEREST = 16,
    IMRDT_QUADRILATERAL = 32
}
//# sourceMappingURL=enumimresultdatatype.d.ts.map