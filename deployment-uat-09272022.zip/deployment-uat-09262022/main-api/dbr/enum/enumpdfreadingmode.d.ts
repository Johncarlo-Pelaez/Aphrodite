export declare enum EnumPDFReadingMode {
    PDFRM_RASTER = 1,
    PDFRM_AUTO = 2,
    PDFRM_VECTOR = 4,
    PDFRM_REV = 2147483648
}
//# sourceMappingURL=enumpdfreadingmode.d.ts.map