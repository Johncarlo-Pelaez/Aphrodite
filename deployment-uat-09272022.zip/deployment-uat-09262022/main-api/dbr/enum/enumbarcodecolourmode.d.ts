export declare enum EnumBarcodeColourMode {
    BICM_DARK_ON_LIGHT = 1,
    BICM_LIGHT_ON_DARK = 2,
    BICM_DARK_ON_DARK = 4,
    BICM_LIGHT_ON_LIGHT = 8,
    BICM_DARK_LIGHT_MIXED = 16,
    BICM_DARK_ON_LIGHT_DARK_SURROUNDING = 32,
    BICM_SKIP = 0,
    BICM_REV = 2147483648
}
//# sourceMappingURL=enumbarcodecolourmode.d.ts.map