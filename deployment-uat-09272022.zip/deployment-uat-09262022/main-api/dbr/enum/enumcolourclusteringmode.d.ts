export declare enum EnumColourClusteringMode {
    CCM_AUTO = 1,
    CCM_GENERAL_HSV = 2,
    CCM_SKIP = 0,
    CCM_REV = 2147483648
}
//# sourceMappingURL=enumcolourclusteringmode.d.ts.map