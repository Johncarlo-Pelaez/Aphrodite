export declare enum EnumTextFilterMode {
    TFM_AUTO = 1,
    TFM_GENERAL_CONTOUR = 2,
    TFM_SKIP = 0,
    TFM_REV = 2147483648
}
//# sourceMappingURL=enumtextfiltermode.d.ts.map