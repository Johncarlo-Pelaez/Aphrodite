1.Backup existing aphrodite
2.Copy and paste the /main-api directory in the existing aphrodite deployment prod.
3.Go to /main-api directory.
  $ cd main-api
4.Install node modules.
  main-api$ npm install
5.Reload main-api
  main-api$ pm2 reload main-api
6. Copy and paste the /main-app directory in the existing aphrodite deployment.
  $ sudo service nginx restart
