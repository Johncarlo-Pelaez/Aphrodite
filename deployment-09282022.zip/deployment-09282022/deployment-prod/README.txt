1.Backup existing aphrodite
2.Copy and paste the /main-api directory in the existing aphrodite deployment prod.
3.Go to /main-api directory.
  $ cd main-api
4.Install node modules.
  main-api$ npm install
5.Edit .env.example to .env and fill then environment of the server
6.Reload main-api
  main-api$ pm2 reload main-api --update-env
7. Copy and paste the /main-app directory in the existing aphrodite deployment.
  $ sudo service nginx restart
8.Update pm2 to rebuild and use the current nodejs version for the main-api instance.
  $pm2 update  
9. Note that handshake code and organization id in the .env must be fill during the production.
