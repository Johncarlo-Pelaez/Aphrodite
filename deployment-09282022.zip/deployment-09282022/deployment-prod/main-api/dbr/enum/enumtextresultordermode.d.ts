export declare enum EnumTextResultOrderMode {
    TROM_CONFIDENCE = 1,
    TROM_POSITION = 2,
    TROM_FORMAT = 4,
    TROM_SKIP = 0,
    TROM_REV = 2147483648
}
//# sourceMappingURL=enumtextresultordermode.d.ts.map