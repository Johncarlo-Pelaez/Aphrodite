export declare enum EnumResultType {
    RT_STANDARD_TEXT = 0,
    RT_RAW_TEXT = 1,
    RT_CANDIDATE_TEXT = 2,
    RT_PARTIAL_TEXT = 3
}
//# sourceMappingURL=enumresulttype.d.ts.map