export declare enum EnumBarcodeComplementMode {
    BCM_AUTO = 1,
    BCM_GENERAL = 2,
    BCM_SKIP = 0,
    BCM_REV = 2147483648
}
//# sourceMappingURL=enumbarcodecomplementmode.d.ts.map