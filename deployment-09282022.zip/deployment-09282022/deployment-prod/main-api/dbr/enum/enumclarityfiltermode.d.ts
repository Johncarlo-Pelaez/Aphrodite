export declare enum EnumClarityFilterMode {
    CFM_GENERAL = 1
}
//# sourceMappingURL=enumclarityfiltermode.d.ts.map