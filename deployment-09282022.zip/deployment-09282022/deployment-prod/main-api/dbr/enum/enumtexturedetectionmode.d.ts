export declare enum EnumTextureDetectionMode {
    TDM_AUTO = 1,
    TDM_GENERAL_WIDTH_CONCENTRATION = 2,
    TDM_SKIP = 0,
    TDM_REV = 2147483648
}
//# sourceMappingURL=enumtexturedetectionmode.d.ts.map