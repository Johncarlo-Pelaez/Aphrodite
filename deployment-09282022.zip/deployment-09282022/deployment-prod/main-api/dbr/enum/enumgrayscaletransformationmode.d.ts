export declare enum EnumGrayscaleTransformationMode {
    GTM_INVERTED = 1,
    GTM_ORIGINAL = 2,
    GTM_SKIP = 0,
    GTM_REV = 2147483648
}
//# sourceMappingURL=enumgrayscaletransformationmode.d.ts.map