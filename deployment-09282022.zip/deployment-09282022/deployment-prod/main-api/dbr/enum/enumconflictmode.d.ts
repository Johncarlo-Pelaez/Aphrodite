export declare enum EnumConflictMode {
    CM_IGNORE = 1,
    CM_OVERWRITE = 2
}
//# sourceMappingURL=enumconflictmode.d.ts.map