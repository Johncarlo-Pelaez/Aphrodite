export interface Region {
    regionBottom: number;
    regionRight: number;
    regionLeft: number;
    regionTop: number;
    regionMeasuredByPercentage: number | boolean;
}
//# sourceMappingURL=region.d.ts.map