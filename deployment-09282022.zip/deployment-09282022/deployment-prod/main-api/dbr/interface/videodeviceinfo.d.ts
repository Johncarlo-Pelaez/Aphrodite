export interface VideoDeviceInfo {
    deviceId: string;
    label: string;
    /** @ignore */
    _checked: boolean;
}
//# sourceMappingURL=videodeviceinfo.d.ts.map