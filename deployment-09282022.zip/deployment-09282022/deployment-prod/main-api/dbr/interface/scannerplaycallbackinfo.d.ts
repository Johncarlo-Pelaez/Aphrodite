export interface ScannerPlayCallbackInfo {
    height: number;
    width: number;
}
//# sourceMappingURL=scannerplaycallbackinfo.d.ts.map