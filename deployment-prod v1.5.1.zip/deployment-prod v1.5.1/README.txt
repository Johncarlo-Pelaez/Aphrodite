1. copy /main-app/build
2. paste /main-app/build
3. $sudo service nginx restart
4. $sudo service nginx status