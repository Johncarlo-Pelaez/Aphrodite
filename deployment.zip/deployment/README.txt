1. Delete /main-api/dist/ directory
2. Copy /main-api/dist/
3. Delete /main-app/build/ directory
4. Copy /main-app/build/
5. Reload all instances in pm2
6. Restart nginx server