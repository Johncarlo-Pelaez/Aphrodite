1. Delete /main-api/dist/ directory
2. Copy /main-api/dist/
3. Check .env.example /main-api directory 
4. Refer .env.example and update existing .env
5. Reload all instances in pm2
6. type in command 'pm2 reload all --update-env'