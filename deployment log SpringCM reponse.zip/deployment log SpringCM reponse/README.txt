1. Delete /main-api/dist/ directory
2. Copy /main-api/dist/
3. Reload all instances in pm2
