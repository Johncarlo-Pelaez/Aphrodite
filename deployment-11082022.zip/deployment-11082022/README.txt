1. Copy and paste the /main-app directory in the existing aphrodite deployment.
  $ sudo service nginx restart