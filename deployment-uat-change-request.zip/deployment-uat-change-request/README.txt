1. copy /main-app/build
2. paste /main-app/build
3. $sudo service nginx restart
4. $sudo service nginx status
5. copy /main-api/dist
6. paste /main-api/dist
7. $pm2 reload main-api