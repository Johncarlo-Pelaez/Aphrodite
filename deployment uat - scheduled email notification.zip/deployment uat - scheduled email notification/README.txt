1.Copy the /main-api directory.
2.Go to /main-api directory.
  $ cd main-api
3.Install node modules.
  main-api$ npm install
