1.Copy and paste /main-api/dist to existing or the path of the instance running in pm2.
  $cp -r deployment-12092022/main-api/dist /home/administrator/src/Aphrodite/main-api
2.Reload updated patch of main-api  
  $pm2 reload main-api
3. Copy and paste main-app/build
  $cp -r deployment-12092022/main-app/build /home/administrator/src/Aphrodite/main-app
4. Restart nginx
  $sudo service nginx restart